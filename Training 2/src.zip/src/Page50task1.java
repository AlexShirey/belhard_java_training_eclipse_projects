
/*
 * Вывести все четные числа от -50 до 50.
 */

public class Page50task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = -50; i <= 50; i++) {
			if (i % 2 == 0 && i != 0) {
				System.out.println(i);
			}
		}

	}

}
